A Pen created at CodePen.io. You can find this one at https://codepen.io/Momciloo/pen/bEdbxY.

 Hello there, good folks!  Today I created  direct messaging screen with bubbles, nice smooth animation, and some cool dynamics, with pure css3 and html5 with almost no jQuery. How do you like it? :)